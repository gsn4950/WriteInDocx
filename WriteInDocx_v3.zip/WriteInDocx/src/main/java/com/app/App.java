package com.app;

import org.apache.log4j.Logger;
import org.apache.log4j.varia.NullAppender;

import com.app.utils.DocxManager;

public class App {

	public static void main(String[] args) {
		
		// Below 2 lines are for removing default logs to be generated from Console
		// String log4jConfPath = System.getProperty("user.dir") + "/log4j.properties";
		// PropertyConfigurator.configure(log4jConfPath);
		Logger.getRootLogger().removeAllAppenders();
		Logger.getRootLogger().addAppender(new NullAppender());
		
		DocxManager manager = new DocxManager();
		
		try {
			manager.run(args[0], args[1]);
		}catch (ArrayIndexOutOfBoundsException e) {
			// Default Height 280px and Weight 500px will be used
			manager.run("280", "500");
		}
		
		
		
		

	}

}
