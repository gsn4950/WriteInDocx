package com.app.utils;

import java.io.File;
import java.util.List;
import java.util.Scanner;

import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;

public class DocxManager {
	
	
	public void run(String height, String weight) {
		System.out.println("APP INFO 	: Application Started...");
		try (Scanner scanner = new Scanner(System.in)) {
			String dirPath;
			String docxName;
			int imageHeight = -1;
			int imageWeight = -1;
			
			System.out.print("Enter Images Directory Path : ");
			dirPath = scanner.nextLine();
			File file = new File(dirPath);
			if(!file.isDirectory()) {
				System.out.println("APP WARNING : Invalid directory provided.");
				System.out.println("APP INFO 	: Application is Shutting Down...");
				System.exit(1);
			}
			
			System.out.print("Enter New Docx File Name : ");
			docxName = scanner.nextLine();
			
			if(docxName.isEmpty()) docxName = "newfile";
			
			if(!docxName.contains(".docx")){
				docxName = docxName + ".docx";
			}

			try {
				imageHeight =   Integer.parseInt(height);
				imageWeight =   Integer.parseInt(weight);
			}catch (ArrayIndexOutOfBoundsException e) {
				// Default Height 280px and Weight 500px will be used
			}catch (NumberFormatException e) {
				System.out.println("APP WARNING : Invalid Height or Weight provided");
				System.out.println("APP INFO : Application is Shutting Down...");
				System.exit(1);
			}
			
			if(imageHeight == -1) imageHeight = 280;
			if(imageWeight == -1) imageWeight = 500;
			
			manage(dirPath, docxName, imageHeight, imageWeight);
			
			System.out.println("APP INFO	: Successfully Created " + docxName + " file");
			System.out.println("APP INFO	: Application Shutting Down with SUCCESS...");
		}
		
	}
	
	public void manage(String dirPath, String newDocxName, int imgHeight, int imgWidth){
		
		Utils.dirValidator(dirPath);
		
		XWPFDocument doc = DocxUtils.createDoc();
		
		XWPFParagraph paragraph = DocxUtils.createNewParagraph(doc);
		
		XWPFRun run = DocxUtils.createRun(paragraph);
		
		List<String> list = Utils.getImagePathAsList(dirPath);
		
		for(int i=0; i < list.size(); i++ ) {
			
			String imgPath = list.get(i);
			
			DocxUtils.addImageInDocx(run, imgPath, imgHeight, imgWidth);
			
			String text = Utils.getSentence(imgPath);
			
			DocxUtils.addTextInDocx(run, text);
			
			DocxUtils.addBreak(run);
		}
		
		DocxUtils.writeToDocxAndClose(doc, dirPath, newDocxName);
		
		
	}

}
