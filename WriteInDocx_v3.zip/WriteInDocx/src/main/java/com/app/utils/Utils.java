package com.app.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

public final class Utils {
	
	private Utils() {}
	
	private static boolean dirValidate(String dirPath) {
		
		File dirPathFile = new File(dirPath);
		
		return dirPathFile.isDirectory();
		
	}
	

	public static void dirValidator(String dirPath) {
		if(!Utils.dirValidate(dirPath)) {
			System.out.println("APP WARNING	: Invalid directory provided.");
			System.out.println("APP INFO	: App is Shutting Down...");
			System.exit(1);
		}
	}
	
	public static List<String> getImagePathAsList(String dirPath){
		List<String> list = new ArrayList<String>();
		
		File dirPathFile = new File(dirPath);
		
		// Getting File list from Directory and adding them in list as String 
			File[] listOfFiles = dirPathFile.listFiles();
			if(listOfFiles.length == 0) {
				System.out.println("APP WARNING	: Provided Directory is Does Not Contain any file");
				System.out.println("APP INFO	: Application is Shutting Down...");
				System.exit(1);
			}

			for (int i = 0; i < listOfFiles.length; i++) {
			  if (listOfFiles[i].isFile()) {
				  list.add(listOfFiles[i].getAbsolutePath());
			  }
			}
			
			list = list.stream()
						.filter(e -> (	e.contains(".png") || 
										e.contains(".PNG") || 
										e.contains(".jpg") || 
										e.contains(".JPG") ||
										e.contains(".jpeg") ||
										e.contains(".JPEG")
									  )
								)
						.collect(Collectors.toList());
			
			// Sorting Lists of String where String contains number
			sortStringList(list);
			
			if(list.size() == 0) {
				System.out.println("APP WARNING	: Provided Directory does not contain any image files. EX: .png .jpg or .jpeg file");
				System.out.println("APP INFO	: Application is Shutting Down...");
				System.exit(1);
			} else {
				System.out.println("APP INFO	: Total Images Found -> " + list.size());
			}
		
			return list;
	}
	
	public static String getSentence(String path) {
	
		int index = path.lastIndexOf("\\");
		if(index < 0) {
			index = path.lastIndexOf("/");
		}
		
		String sentence = path.substring(index + 1);
		
		if(sentence.contains(".png")) sentence = sentence.replace(".png", "");
		else if (sentence.contains(".PNG")) sentence = sentence.replace(".PNG", "");
		else if (sentence.contains(".jpg")) sentence = sentence.replace(".jpg", "");
		else if (sentence.contains(".JPG")) sentence = sentence.replace(".JPG", "");
		else if (sentence.contains(".jpeg")) sentence = sentence.replace(".jpeg", "");
		else if (sentence.contains(".JPEG")) sentence = sentence.replace(".JPEG", "");
		
		return sentence;
	}
	
	public static String patternMatcherForListSorting(String orgText) {
		Pattern pattern = Pattern.compile("(\\d*_)+\\D", Pattern.CASE_INSENSITIVE);
	    Matcher matcher = pattern.matcher(orgText);
	    boolean matchFound = matcher.find();
	    if(matchFound) {
	      return matcher.group(0);
	    } else {
	      return "";
	    }
	}
	
	private static void sortStringList(List<String> lists) {
		boolean flag = lists.stream().allMatch(e -> !Utils.patternMatcherForListSorting(e).isEmpty());
		if(flag) {
			Utils.sortStringListWithPatternMatcher(lists);
		}
		else {
			Utils.sortStringListWithoutPatternMatcher(lists);
		}
	}
	
	private static void sortStringListWithPatternMatcher(List<String> lists) {
		Collections.sort(lists, new Comparator<String>() {
	        public int compare(String o1, String o2) {
    	
	        	String s1 = Utils.patternMatcherForListSorting(o1);
	        	String s2 = Utils.patternMatcherForListSorting(o2);
	        	
	        	int i1 = s1.lastIndexOf("_");
	        	int i2 = s2.lastIndexOf("_");
	        	
	        	String s3 =  s1.substring(0, i1);
	        	String s4 =  s2.substring(0, i2);

	        	String s5 =  s3.replaceFirst("_", ".");
	        	String s6 =  s4.replaceFirst("_", ".");
	        	
	        	double d1 = 0.00;
	        	double d2 = 0.00;
	        	try {
	        		d1 = Double.parseDouble(s5);
	        		d2 = Double.parseDouble(s6);
	        	} catch(Exception e){
	        		System.out.println("APP WARNING : Double parsing erro at method Utils.sortStringListWithPatternMatcher()");
	        		System.out.println("APP INFO : Application is Shutting Down...");
	        		System.exit(1);
	        	}
	        	

	        	return Double.compare(d1, d2);
	        }

//	        int extractInt(String s) {
//	            String num = s.replaceAll("\\D", "");
//	            // return 0 if no digits found
//	            return num.isEmpty() ? 0 : Integer.parseInt(num);
//	        }

	    });
	}
	
   private static void sortStringListWithoutPatternMatcher(List<String> lists) {
	   Collections.sort(lists, new Comparator<String>() {
	        public int compare(String o1, String o2) {
	        	
	        	if( extractInt(o1) == -404 || extractInt(o1) == -404) {
	        		return o1.compareTo(o2);
	        	}
	        	
	            return extractInt(o1) - extractInt(o2);
	        }

	        int extractInt(String s) {
	        	
	        	String num = "";
	        	try {
	        		num = s.replaceAll("\\D", "");
	        		// return 0 if no digits found
	        		return num.isEmpty() ? 0 : Integer.parseInt(num);
	        		
	        	}catch(Exception e) {
	        		return -404;
	        	}

	        }
	    });
	}
	
   
	public static void closeFileInputStream(FileInputStream fis) {
		try {
			fis.close();
		} catch (IOException e) {
			System.out.println("APP WARNING	: Failed to close FileInputStream");
			System.out.println("APP INFO	: Application is Shutting Down");
			System.exit(1);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println("APP WARNING	: Failed to close FileInputStream");
				System.out.println("APP INFO	: Application is Shutting Down");
				System.exit(1);
			}
		}
	}
	
   
	public static void closeFileOutputStream(FileOutputStream fos) {
		try {
			fos.close();
		} catch (IOException e) {
			System.out.println("APP WARNING	: Failed to close FileOutputStream");
			System.out.println("APP INFO	: Application is Shutting Down");
			System.exit(1);
		} finally {
			try {
				fos.close();
			} catch (IOException e) {
				System.out.println("APP WARNING	: Failed to close FileOutputStream");
				System.out.println("APP INFO	: Application is Shutting Down");
				System.exit(1);
			}
		}
	}
	
	
	
	
	
	
	
	
	
	
	/*
	public static List<FileInputStream> getFileInputStream(String dirPath) {
		List<FileInputStream> fisList = new ArrayList<>();
		
		List<String> fileList = getImagePathAsList(dirPath);
		
		for(int i=0; i< fileList.size(); i++) {
			File image = null;
			FileInputStream imageData = null;
			try {
	        	image = new File(fileList.get(i));
				imageData = new FileInputStream(image);
				fisList.add(imageData);
			} catch (FileNotFoundException e2) {
				System.out.println("APP WARNING	: Invalid image Path Provided in index " + i + ".");
				System.out.println("APP INFO	: Application is Shutting Down...");
				System.exit(1);
			}
		}
		return fisList;		
		
	}
	*/
	
	/*
	public static List<String> getFileNamesAndCreateSentences(String dirPath) {
		
		List<String> list = new ArrayList<String>();
		
		//String dirPath = "C:/Users/ssi49/Desktop/test";
		
		File dirPathFile = new File(dirPath);
		
		// if provided path does not exists, then return an empty List object
		// if(!dirPathFile.isDirectory()) return Collections.emptyList();
		
		
		// Getting File list from Directory and adding them in list as String 
		File[] listOfFiles = dirPathFile.listFiles();

		for (int i = 0; i < listOfFiles.length; i++) {
		  if (listOfFiles[i].isFile()) {
			  list.add(listOfFiles[i].getName());
		  }
		}
		
		// Removing files that does not contain (.png or .jpg or .jpeg) 
		// Removing extention from file name
		// Sort the List in Ascending order
		list = list.parallelStream()
			.filter(e -> (e.contains(".png") || e.contains(".jpg") || e.contains(".jpeg")))
			.map( e -> {
						if(e.contains(".png")) return e.replace(".png", "");
						if(e.contains(".jpg")) return e.replace(".jpg", "");
						if(e.contains(".jpeg")) return e.replace(".jpeg", "");
						return e;
					    }
					)	
			.sorted()
			.collect(Collectors.toList());
		
		
		
		return list;
	}
	*/
	
	/*
	public static String getFormatedDirPath(String propertiesFilePath) {
		
        File file = null;
        BufferedReader br = null;
        String dirPath = "";
        try {
        	file = new File(propertiesFilePath);
        	br = new BufferedReader(new FileReader(file));
        	String st;
        	while ((st = br.readLine()) != null) {
            	if(st.contains("dirPath=")) {
            		st = st.replace("dirPath=", "");
            		dirPath = st.replace("\\", "/");
            		break;
            	}
            }
        }catch (Exception e) {
			System.out.println("APP WARNING: Error while reading app.properties file");
			System.out.println("APP WARNING: Application is Shutting Down...");
			System.exit(1);
		} finally {
			try {
				br.close();
			} catch (IOException e) {
				System.out.println("APP WARNING: Error while reading app.properties file");
				System.out.println("APP WARNING: Application is Shutting Down...");
				System.exit(1);
			}
		}
        
        return dirPath;
	}
	*/
}
