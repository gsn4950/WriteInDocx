package com.app.config;

import org.aeonbits.owner.ConfigFactory;

import com.app.utils.Utils;

public final class ConfigReader {
	
	private ConfigReader() {}
	
	private static final AppConfig appConfig = ConfigFactory.create(AppConfig.class);
	
	public static String getDirPath() {
		//String dirPath = appConfig.getDirPath();
		
		String homeDir = System.getProperty("user.dir") + "/";
		String appPropertiesFileName = "app.properties";
		String fullPropertiesFilePath = homeDir + appPropertiesFileName;
		
		String dirPath = Utils.getFormatedDirPath(fullPropertiesFilePath).trim();
		
		int lastIndex = dirPath.length() - 1;
		char ch = dirPath.charAt(lastIndex);
		
		if(ch == '/' || ch == '\\') {
			dirPath = dirPath.substring(0, lastIndex);
		}

		return dirPath;
	}
	
	public static String getNewDocxFileName() {
		String name = appConfig.getNewDocxFileName();
		
		if(!name.contains(".docx")){
			name = name + ".docx";
		}
		
		return name.trim();
	} 
	
	public static int getImageHeight() {
		return appConfig.getImageHeight();
	}
	
	public static int getImageWidth() {
		return appConfig.getImageWidth();
	}

}
